int main() { return 0; }
int t() {
XmGetPixmap()
; return 0; }
