/* config.h.  Generated automatically by configure.  */
#define HAVE_IPC_H 1
#define HAVE_SHM_H 1
#define HAVE_XSHM_H 1

#define TIME_WITH_SYS_TIME 1
#define HAVE_SYS_TIME_H 1
#define HAVE_UNISTD_H 1

#define HAVE_DIRENT_H 1
/* #undef HAVE_SYS_NDIR_H */
/* #undef HAVE_SYS_DIR_H */
/* #undef HAVE_NDIR_H */

#define RETSIGTYPE void
#define HAVE_VPRINTF 1
/* #undef HAVE_DOPRNT */
